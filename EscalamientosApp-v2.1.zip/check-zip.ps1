Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead('C:\Users\the_f\OneDrive\Escritorio\EscalamientosApp-1.1\EscalamientosApp-v2.1.zip')
Write-Host "Total entradas: $($zip.Entries.Count)"
$zip.Entries | ForEach-Object { Write-Host $_.FullName }
$zip.Dispose()
